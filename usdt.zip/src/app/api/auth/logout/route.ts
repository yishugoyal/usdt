import { NextResponse } from 'next/server';

export async function POST() {
  const response = NextResponse.json({ success: true, message: 'Logged out' });
  response.cookies.delete('rb_user_token');
  response.cookies.delete('rb_staff_token');
  return response;
}
